package Repository;

public class PurchaseRepository {

}
