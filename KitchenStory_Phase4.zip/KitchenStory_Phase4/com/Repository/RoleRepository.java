package Repository;

public class RoleRepository {

}
