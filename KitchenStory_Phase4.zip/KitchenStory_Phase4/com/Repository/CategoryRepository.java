package Repository;

public class CategoryRepository {

}
