
public class KitchenStory {

}
