package Model;

public class Purchase {

}
