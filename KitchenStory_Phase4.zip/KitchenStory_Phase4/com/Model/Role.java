package Model;

public class Role {

}
